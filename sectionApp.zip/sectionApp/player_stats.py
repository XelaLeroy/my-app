from flask import Flask, jsonify, Blueprint, render_template
import requests
from bs4 import BeautifulSoup
import json
from selenium import webdriver 
from selenium.webdriver.chrome.options import Options
from flask_cors import CORS
from itertools import groupby



app = Flask(__name__)
CORS(app)

stats = Blueprint('stats',__name__,template_folder='templates')



@stats.route('/top14_player_stats')
def index():
    chrome_driver_path = "C:/Users/leroy/Desktop/SectionPaloise/my-app/sectionApp/chromedriver-win64/chromedriver.exe"
    driver = webdriver.Chrome(executable_path=chrome_driver_path)
    driver.get("https://top14.lnr.fr/club/pau/statistiques") 
    content = driver.page_source
    soup = BeautifulSoup(content, 'html.parser')
    players = soup.find_all('player-row')
    print(players)

    # numbers = soup.find_all('players-ranking__wrapper')
  


    player_stats = []
    
    for player in players:

         
        player_name = player.select('.player-row__cell .player-cell .player-cell__name')[0].get_text(strip=True)
            #  player_image = player[i]['player']['image']['original']
            #  tries = player[i]['player']['image']['original']
            #  games = number[i]['player']['image']['original']
            #  minutes = number[i]['player']['image']['original']
            #  points = number[i]['player']['image']['original']
            #  offload = number[i]['player']['image']['original']
            #  yellowCard = number[i]['player']['image']['original']
            #  redCard = number[i]['player']['image']['original']
            #  tackles = number[i]['player']['image']['original']
            #  franchissement = number[i]['player']['image']['original']
            # Ajoutez les informations du joueur à la liste

        player_info = {
                "name" : player_name,
            }
                
        player_stats.append(player_info)
    
    driver.quit()


    # # Utilisez jsonify pour renvoyer la liste complète des informations des joueurs
    return jsonify(player_stats)




if __name__ == '__main__':
    app.run(debug=True)